<?php
namespace Omeka\Job\Exception;

class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
