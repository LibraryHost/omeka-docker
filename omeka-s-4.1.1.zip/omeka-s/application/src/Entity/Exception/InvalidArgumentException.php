<?php
namespace Omeka\Entity\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
