<?php
namespace Omeka\Controller;

use Laminas\Mvc\Controller\AbstractActionController;

class MaintenanceController extends AbstractActionController
{
    public function indexAction()
    {
    }
}
